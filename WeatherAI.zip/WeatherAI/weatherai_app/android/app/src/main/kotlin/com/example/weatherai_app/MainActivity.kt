package com.example.weatherai_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
